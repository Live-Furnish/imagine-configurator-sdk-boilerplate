# Sectional sofa catalog bundle - placeholder

This bundle is not published yet. When it lands, this archive will contain:

    sectional-sofa-import/
    |- catalog.xlsx   the import workbook
    |- models/        component GLBs
    |- textures/      upholstery + finish maps
    +- thumbnails/    option thumbnails

Import steps (unchanged when the real assets arrive): extract this zip, then
drop the extracted sectional-sofa-import folder on the admin panel Catalog Import
folder picker. Do not upload the zip itself - catalog.xlsx must sit at the
root of what you hand the importer.

See docs/import-sample-catalog.md in the repo.

Assets are licensed for non-commercial use only, permanently.
See data-samples/LICENSE-ASSETS.md.
