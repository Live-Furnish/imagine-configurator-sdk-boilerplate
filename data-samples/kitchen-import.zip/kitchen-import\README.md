# Kitchen catalog bundle - placeholder

This bundle is not published yet. When it lands, this archive will contain:

    kitchen-import/
    |- catalog.xlsx   the import workbook
    |- models/        component GLBs
    |- materials/     PBR texture maps
    +- thumbnails/    option thumbnails

Import steps (unchanged when the real assets arrive): extract this zip, then
drop the extracted kitchen-import folder on the admin panel Catalog Import
folder picker. Do not upload the zip itself - catalog.xlsx must sit at the
root of what you hand the importer.

See docs/import-sample-catalog.md in the repo.

Assets are licensed for non-commercial use only, permanently.
See data-samples/LICENSE-ASSETS.md.
